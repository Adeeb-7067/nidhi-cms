# Graph Report - backend  (2026-05-21)

## Corpus Check
- 106 files · ~44,139 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 636 nodes · 1300 edges · 37 communities (33 shown, 4 thin omitted)
- Extraction: 97% EXTRACTED · 3% INFERRED · 0% AMBIGUOUS · INFERRED: 41 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `a6d629ec`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]
- [[_COMMUNITY_Community 3|Community 3]]
- [[_COMMUNITY_Community 4|Community 4]]
- [[_COMMUNITY_Community 5|Community 5]]
- [[_COMMUNITY_Community 6|Community 6]]
- [[_COMMUNITY_Community 7|Community 7]]
- [[_COMMUNITY_Community 8|Community 8]]
- [[_COMMUNITY_Community 9|Community 9]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]
- [[_COMMUNITY_Community 15|Community 15]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 18|Community 18]]
- [[_COMMUNITY_Community 19|Community 19]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 22|Community 22]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]

## God Nodes (most connected - your core abstractions)
1. `getNextSequence()` - 40 edges
2. `badRequest()` - 29 edges
3. `parseIdParam()` - 29 edges
4. `notFound()` - 26 edges
5. `optionalString()` - 26 edges
6. `requireAuth()` - 23 edges
7. `guard()` - 22 edges
8. `parsePagination()` - 21 edges
9. `requireRole()` - 20 edges
10. `paginateModel()` - 17 edges

## Surprising Connections (you probably didn't know these)
- `main()` --calls--> `getNextSequence()`  [INFERRED]
  scripts/seed-more.ts → src/models/schema/counter.ts
- `main()` --calls--> `getNextSequence()`  [INFERRED]
  scripts/seed.ts → src/models/schema/counter.ts
- `buildAll()` --calls--> `esbuild`  [INFERRED]
  build.mjs → package.json
- `postProjectsByIdMembers()` --calls--> `getNextSequence()`  [INFERRED]
  src/controllers/projects.controller.ts → src/models/schema/counter.ts
- `postProjectsByIdApkSchedules()` --calls--> `getNextSequence()`  [INFERRED]
  src/controllers/projects.controller.ts → src/models/schema/counter.ts

## Communities (37 total, 4 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.07
Nodes (61): formatAuthUser(), getAuthMe(), patchAuthMe(), postAuthFcmToken(), postAuthForgotPassword(), postAuthImpersonateByUserId(), postAuthLogin(), postAuthRefresh() (+53 more)

### Community 1 - "Community 1"
Cohesion: 0.08
Nodes (31): verifyAccessToken(), extractBearerToken(), Request, requireAuth(), requireRole(), router, router, forgotPasswordLimiter (+23 more)

### Community 2 - "Community 2"
Cohesion: 0.08
Nodes (38): getClients(), formatComment(), patchCommentsById(), postComments(), getCompanies(), buildLogsListQuery(), canAccessLog(), formatLog() (+30 more)

### Community 3 - "Community 3"
Cohesion: 0.07
Nodes (21): getProjectsById(), getProjectsByIdApkReleases(), getProjectsByIdBugs(), getProjectsByIdHistory(), patchProjectsById(), postProjectsByIdApkSchedules(), postProjectsByIdMembers(), postProjectsByIdMilestones() (+13 more)

### Community 4 - "Community 4"
Cohesion: 0.14
Nodes (30): deleteProjectsByProjectIdInventoryCredentialsById(), deleteProjectsByProjectIdInventoryResourcesById(), getProjectsByProjectIdInventoryActivities(), getProjectsByProjectIdInventoryBuilds(), getProjectsByProjectIdInventoryCredentials(), getProjectsByProjectIdInventoryDevices(), getProjectsByProjectIdInventoryEnvironments(), getProjectsByProjectIdInventoryFolders() (+22 more)

### Community 5 - "Community 5"
Cohesion: 0.14
Nodes (27): formatRelease(), getApkReleasesById(), postProjectsByIdApkReleases(), buildBugListQuery(), generateBugNumber(), getBugs(), getBugsById(), patchBugsById() (+19 more)

### Community 6 - "Community 6"
Cohesion: 0.12
Nodes (28): getReportsByIdDownload(), postReports(), parseCategory(), postUpload(), ensureLocalUploadDir(), getStorageBackend(), localFilename(), resolvePublicFileUrl() (+20 more)

### Community 7 - "Community 7"
Cohesion: 0.12
Nodes (18): DB, isDatabaseConnected(), safeUrl, whenDatabaseReady(), getFirebaseAdmin(), initFirebaseAdmin(), logger, initRealtime() (+10 more)

### Community 8 - "Community 8"
Cohesion: 0.09
Nodes (19): assignHandlerNames(), callEnd, callText, controllersDir, ctrlPath, def, __dirname, extra (+11 more)

### Community 9 - "Community 9"
Cohesion: 0.09
Nodes (23): apkDownloadLogSchema, ApkPlatform, apkPlatforms, ApkRelease, apkReleaseSchema, ApkReleaseType, apkReleaseTypes, ApkAudience (+15 more)

### Community 10 - "Community 10"
Cohesion: 0.10
Nodes (20): activitySchema, credentialAccessLogSchema, credentialSchema, deviceSchema, environmentSchema, folderSchema, InventoryCredentialType, inventoryCredentialTypes (+12 more)

### Community 11 - "Community 11"
Cohesion: 0.10
Nodes (20): dependencies, @aws-sdk/client-s3, bcryptjs, compression, cors, exceljs, express, express-async-handler (+12 more)

### Community 12 - "Community 12"
Cohesion: 0.11
Nodes (18): compilerOptions, baseUrl, esModuleInterop, isolatedModules, lib, module, moduleResolution, noEmitOnError (+10 more)

### Community 13 - "Community 13"
Cohesion: 0.19
Nodes (12): HttpError, isHttpError(), statusToCode(), formatZodError(), toApiErrorBody(), duplicateKeyMessage(), errorHandler(), isCastError() (+4 more)

### Community 14 - "Community 14"
Cohesion: 0.13
Nodes (15): devDependencies, esbuild-plugin-pino, nodemon, pino-pretty, thread-stream, tsx, @types/bcryptjs, @types/compression (+7 more)

### Community 15 - "Community 15"
Cohesion: 0.14
Nodes (13): CredentialHistory, credentialHistorySchema, CredentialTrigger, credentialTriggers, passwordResetTokensSchema, Session, sessionsSchema, User (+5 more)

### Community 16 - "Community 16"
Cohesion: 0.18
Nodes (10): Bug, BugPlatform, bugPlatforms, bugPriorities, BugPriority, bugSchema, bugSeverities, BugSeverity (+2 more)

### Community 17 - "Community 17"
Cohesion: 0.20
Nodes (9): CMS Backend (API), code:block1 (src/), code:powershell (cd backend), code:env (ALLOWED_ORIGINS=https://app.yourdomain.com), Core dependencies (security-related), MVC layout, Scripts, Setup (+1 more)

### Community 18 - "Community 18"
Cohesion: 0.22
Nodes (9): scripts, build, dev, dev:once, migrate-company, seed, seed-more, start (+1 more)

### Community 19 - "Community 19"
Cohesion: 0.22
Nodes (8): RequestStatus, requestStatuses, RequestType, requestTypes, requestUrgencies, RequestUrgency, ResourceRequest, resourceRequestSchema

### Community 20 - "Community 20"
Cohesion: 0.22
Nodes (8): Task, taskPriorities, TaskPriority, taskSchema, TaskStatus, taskStatuses, TaskType, taskTypes

### Community 21 - "Community 21"
Cohesion: 0.29
Nodes (6): Ticket, ticketPriorities, TicketPriority, ticketSchema, TicketStatus, ticketStatuses

### Community 22 - "Community 22"
Cohesion: 0.29
Nodes (6): Report, reportSchema, ReportStatus, reportStatuses, ReportType, reportTypes

### Community 23 - "Community 23"
Cohesion: 0.29
Nodes (3): AssignBugBody, ListAssignableMembersParams, router

### Community 24 - "Community 24"
Cohesion: 0.33
Nodes (5): delay, exec, ext, ignore, watch

### Community 25 - "Community 25"
Cohesion: 0.33
Nodes (5): dirs, full, root, serviceModules, src

### Community 26 - "Community 26"
Cohesion: 0.70
Nodes (4): backfillFromProjects(), backfillProjects(), main(), normalizeCompanies()

### Community 27 - "Community 27"
Cohesion: 0.40
Nodes (4): name, private, type, version

### Community 28 - "Community 28"
Cohesion: 0.40
Nodes (4): Client, clientSchema, ClientStatus, clientStatuses

### Community 29 - "Community 29"
Cohesion: 0.40
Nodes (4): Comment, commentSchema, ThreadType, threadTypes

### Community 30 - "Community 30"
Cohesion: 0.50
Nodes (3): artifactDir, buildAll(), esbuild

## Knowledge Gaps
- **251 isolated node(s):** `artifactDir`, `watch`, `ext`, `ignore`, `exec` (+246 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **4 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `getNextSequence()` connect `Community 4` to `Community 0`, `Community 2`, `Community 3`, `Community 5`, `Community 6`?**
  _High betweenness centrality (0.025) - this node is a cross-community bridge._
- **Why does `badRequest()` connect `Community 0` to `Community 2`, `Community 3`, `Community 5`, `Community 6`?**
  _High betweenness centrality (0.011) - this node is a cross-community bridge._
- **Why does `parseIdParam()` connect `Community 0` to `Community 2`, `Community 3`, `Community 5`?**
  _High betweenness centrality (0.010) - this node is a cross-community bridge._
- **Are the 39 inferred relationships involving `getNextSequence()` (e.g. with `main()` and `main()`) actually correct?**
  _`getNextSequence()` has 39 INFERRED edges - model-reasoned connections that need verification._
- **What connects `artifactDir`, `watch`, `ext` to the rest of the system?**
  _251 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Community 0` be split into smaller, more focused modules?**
  _Cohesion score 0.07450444292549556 - nodes in this community are weakly interconnected._
- **Should `Community 1` be split into smaller, more focused modules?**
  _Cohesion score 0.083710407239819 - nodes in this community are weakly interconnected._